window.EVE = {
state: "WATCHING",
analyze(data) {
  if (!data) return "NO DATA";
  return "LIVE ROWS: " + data.length;
}
};

document.addEventListener("data:update", () => {
  console.log("EVE:", EVE.analyze(window.liveData));
});