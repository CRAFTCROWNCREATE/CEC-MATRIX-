const SHEET_URL = "PASTE_YOUR_GOOGLE_SHEET_JSON_URL_HERE";

async function fetchLiveData() {
  const res = await fetch(SHEET_URL);
  const text = await res.text();
  const json = JSON.parse(text.substring(47).slice(0, -2));
  return json.table.rows.map(r => r.c.map(c => c ? c.v : null));
}

async function updateDataLoop() {
  try {
    window.liveData = await fetchLiveData();
    document.dispatchEvent(new Event("data:update"));
  } catch (e) {
    console.error(e);
  }
}

setInterval(updateDataLoop, 5000);
updateDataLoop();