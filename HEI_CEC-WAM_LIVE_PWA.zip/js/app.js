document.addEventListener("data:update", () => {
document.getElementById("eve-status").innerText =
  "EVE: SYNC " + new Date().toLocaleTimeString();
});