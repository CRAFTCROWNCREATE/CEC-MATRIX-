HEI / CEC-WAM LIVE PWA
1. Upload to GitHub
2. Enable Pages
3. Paste Google Sheet JSON URL
4. Install on phone